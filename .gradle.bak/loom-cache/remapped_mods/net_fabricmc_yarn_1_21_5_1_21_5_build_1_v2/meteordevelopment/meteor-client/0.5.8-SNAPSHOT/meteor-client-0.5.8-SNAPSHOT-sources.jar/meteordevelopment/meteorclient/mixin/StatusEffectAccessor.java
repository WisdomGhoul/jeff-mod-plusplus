/*
 * This file is part of the Meteor Client distribution (https://github.com/MeteorDevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.registry.entry.RegistryEntry;

@Mixin(StatusEffect.class)
public interface StatusEffectAccessor {
    @Accessor
    Map<RegistryEntry<EntityAttribute>, StatusEffect.EffectAttributeModifierCreator> getAttributeModifiers();
}
